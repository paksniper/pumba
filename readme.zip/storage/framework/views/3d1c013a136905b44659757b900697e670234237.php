<?php $__env->startSection('content'); ?>
    <!-- Displaying All Products Start Here -->

    <section id="product-detail" class="my-5">
        <div class="container p-0">
            <div class="row">
                <div class="col-md-3 border p-0">
                    <div class="p-2 border-bottom-0">
                        <h6 class="font-weight-bold">FILTERS</h6>
                    </div>
                    <div class="card mb-3 border-top-0 border-left-0 border-right-0 rounded-0 border-bottom">
                        <div class="card-footer border-bottom p-2 bg-white categories-btn">
                            <div class="card-text float-left">Categories</div>
                            <span class="float-right fas fa-angle-up cat-slide-icon mt-1"></span>
                        </div>
                        <div class="card-body categories-container p-1">
                            <ul class="list-unstyled categories mCustomScrollbar" data-mcs-theme="dark">
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="subcategory-item-container">
                                        <li class="d-block py-2 align-items-center px-2 subcategory-item">
                                            <img class="img-fluid" src="<?php echo e(asset('storage/images/subcategories/bra.png')); ?>" >
                                            <span class="ml-3"><?php echo e(\Illuminate\Support\Str::slug($subcat->subcategory," ")); ?></span>
                                        </li>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="card border-top-0 border-left-0 border-right-0 rounded-0 border-bottom">
                        <div class="card-footer border-bottom p-2 bg-white brands-btn">
                            <div class="card-text float-left">Brands</div>
                            <span class="float-right fas fa-angle-up brand-slide-icon mt-1"></span>
                        </div>
                        <div class="card-body brands-container p-1">
                            <ul class="list-unstyled brands mCustomScrollbar" data-mcs-theme="dark">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="subcategory-item-container">
                                        <li class="d-block py-2 align-items-center px-2 subcategory-item">
                                            <img class="img-fluid" src="<?php echo e(asset('storage/images/brands/brand.png')); ?>" >
                                            <span class="ml-3"><?php echo e(\Illuminate\Support\Str::slug($brand->title," ")); ?></span>
                                        </li>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card bg-white">
                        <div class="card-header bg-white">
                            Search Result(<?php echo e($count); ?> Products Found)
                        </div>
                        <div class="card-body">
                            <div class="row mb-2">
                                <?php if($searchproducts !== ""): ?>
                                    <?php $__currentLoopData = $searchproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 px-1 product-on-view">
                                            <?php $__env->startComponent('components.product_card'); ?>
                                                <?php $__env->slot('product_img_url'); ?>
                                                    <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                                    <?php $__env->slot('image_source'); ?>
                                                        <?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/'.$product->image)); ?>

                                                    <?php $__env->endSlot(); ?>
                                                <?php $__env->endSlot(); ?>

                                                <?php $__env->slot('product_title_url'); ?>
                                                    <?php echo e(route('product_detail',$product->image )); ?>

                                                    <?php $__env->slot('product_title'); ?>
                                                        <?php echo e($product->title); ?>

                                                    <?php $__env->endSlot(); ?>
                                                <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('discount_price'); ?>
                                                        <?php if($product->discount != ""): ?>
                                                            <span class="text-success">Rs.&nbsp<?php echo e($product->discount); ?></span>
                                                        <?php endif; ?>
                                                    <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('original_price'); ?>
                                                        <?php if($product->discount != ""): ?>
                                                            &nbsp<s class="text-muted"><small>Rs.&nbsp<?php echo e($product->price); ?></small></s>
                                                        <?php else: ?>
                                                            &nbsp<span class="text-success">Rs.&nbsp<?php echo e($product->price); ?></span>
                                                        <?php endif; ?>

                                                    <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('discount_percentage'); ?>
                                                        <?php if($product->discount != ""): ?>
                                                            &nbsp;<span class="text-danger"><?php echo e($product->percentage); ?>% Off</span>
                                                        <?php endif; ?>
                                                    <?php $__env->endSlot(); ?>
                                            <?php echo $__env->renderComponent(); ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>


                    <!-- Pagination starts here -->
                    <div class="row mt-5">
                        <div class="col showing-page-tag">
                            <?php if(!empty($count)): ?>
                                Showing Page <?php echo e($searchproducts->currentPage()); ?> of <?php echo e($searchproducts->lastPage()); ?>

                            <?php endif; ?>
                        </div>
                        <div class="col d-flex justify-content-end">
                            <?php if(!empty($count)): ?>
                                <?php echo e($searchproducts->links()); ?>

                            <?php endif; ?>
                        </div>

                    </div>

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <!-- Pagination ends here -->
                </div>
            </div>
        </div>
    </section>
    <!-- Product Detail Ends Here -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make(\Illuminate\Support\Facades\Auth::guard('admin')->check() ?'layout.admin_app':'layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/project_rest_layout/view_all_search_products.blade.php ENDPATH**/ ?>