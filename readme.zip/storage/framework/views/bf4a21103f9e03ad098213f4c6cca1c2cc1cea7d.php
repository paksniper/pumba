<?php $__env->startSection('title'); ?>
    PumbaShopping
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(\Illuminate\Support\Facades\Session::has('status')): ?>
        <div class="mt-3 p-3 text-center alert alert-success alert-dismissible show fade">
            <?php echo e(\Illuminate\Support\Facades\Session::get('status')); ?>

            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="container mt-5">
        <div class="row">
            <div id="accordion" class="w-100">
                <div class="card">
                    <div class="card-footer bg-white border-bottom border-top-0">
                        <button class="btn" data-toggle="collapse" style="background-color: #aa1dbf; color: white;" data-target="#create-product">
                            <i class="fas fa-plus-circle" style="color: white;"></i> Create A Filter Subcategory
                        </button>
                    </div>
                    <div class="collapse show" id="create-product" data-parent="#accordion">
                        <div class="card-body">
                            <form
                                action="<?php echo e(route('create_filter_subcategory')); ?>"
                                method="post"
                                enctype="application/x-www-form-urlencoded"
                                id="category_form"
                                name="category_form">
                                <?php echo csrf_field(); ?>
                                <div class="col-md m-0 px-1">
                                    <div class="form-group w-100">
                                        <label for="section" class="form-label">Category</label>
                                        <select id="filter-category" class="form-control <?php $__errorArgs = ['filter_subcategory_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="filter_subcategory_category">
                                            <?php if($categories->isEmpty()): ?>
                                                <option value="">No Category Available</option>
                                            <?php else: ?>
                                                <option value="">Select a Category</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->category); ?>">
                                                        <?php echo e(\Illuminate\Support\Str::slug($category->category,' ')); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['filter_subcategory_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="category_title" class="form-label">Title</label>
                                    <input type="text" name="filter_subcategory_title"
                                           class="form-control <?php $__errorArgs = ['filter_subcategory_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="Filter subcategory title..." value="<?php echo e(old('filter_subcategory_title')); ?>">
                                    <?php $__errorArgs = ['filter_subcategory_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mx-auto">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-block"
                                                    style="background-color: #aa1dbf; color: white;">
                                                Create Filter Subcategory
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row px-auto">
            <div class="col-md">
                <?php if(!$subcategory_filters->isEmpty()): ?>
                    <table id="data-table" class="table table-bordere table-hover table-stripe w-100"
                           style="font-size: 16px; width: 100%;">
                        <thead>
                        <th>Id</th>
                        <th>Category</th>
                        <th>Subcategory</th>
                        <th>Action</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $subcategory_filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($subcategory->id); ?></td>
                                <td><?php echo e($subcategory->category); ?></td>
                                <td><?php echo e($subcategory->subcategory); ?></td>
                                <td><a href="<?php echo e(route('admin_edit_filter_subcategory_view',$subcategory->id)); ?>" class="edit-text" title="edit product"><i class="far fa-edit"></i></a>
                                    &nbsp;
                                    <form id="delete_form<?php echo e($subcategory->id); ?>" class="d-inline" action="<?php echo e(route('delete_filter_subcategory',$subcategory->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="delete-text bg-transparent border-0" title="delete brand"
                                                data-toggle="modal" data-target="#confirmation_modal<?php echo e($subcategory->id); ?>"><i
                                                class="far fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-center">No Filter Subcategories To Display</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php $__currentLoopData = $subcategory_filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('components.confirmation_modal'); ?>
            <?php $__env->slot('modal_id'); ?>
                <?php echo e($subcategory->id); ?>

            <?php $__env->endSlot(); ?>
            <?php $__env->slot('btn_id'); ?>
                <?php echo e($subcategory->id); ?>

            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/admin/filter_subcategory.blade.php ENDPATH**/ ?>