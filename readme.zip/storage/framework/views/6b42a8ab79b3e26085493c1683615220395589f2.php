<?php $__env->startSection('title'); ?>
    PumbaShopping
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(\Illuminate\Support\Facades\Session::has('status')): ?>
        <div class="mt-3 p-3 text-center alert alert-success alert-dismissible show fade">
            <?php echo e(\Illuminate\Support\Facades\Session::get('status')); ?>

            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="container mt-5">
        <div class="row">
            <div id="accordion" class="w-100">
                <div class="card">
                    <div class="card-footer bg-white border-bottom border-top-0">
                        <button class="btn btn-outline-primary" data-toggle="collapse" data-target="#create-product">
                            <i class="fas fa-plus-circle"></i> Create A Product
                        </button>
                    </div>

                    <div class="collapse show" id="create-product" data-parent="#accordion">
                        <div class="card-body">
                            <form
                                action="<?php echo e(route('create_product')); ?>"
                                method="post"
                                enctype="multipart/form-data"
                                id="product_form"
                                name="product_form">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md m-0 px-1">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">Section</label>
                                            <select class="form-control <?php $__errorArgs = ['product_section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_section">
                                                <?php if($sections->isEmpty()): ?>
                                                    <option value="">No Section Available</option>
                                                <?php else: ?>
                                                    <option value="">Select Section</option>
                                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($section->title); ?>">
                                                            <?php echo e(\Illuminate\Support\Str::slug($section->title,' ')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md m-0 px-1">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">Fashion</label>
                                            <select id="fashion"
                                                    class="form-control <?php $__errorArgs = ['product_fashion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_fashion">
                                                <?php if($fashions->isEmpty()): ?>
                                                    <option value="">No Fashion Available</option>
                                                <?php else: ?>
                                                    <option value="">Select Fashion</option>
                                                    <?php $__currentLoopData = $fashions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fashion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($fashion->fashion); ?>">
                                                            <?php echo e(\Illuminate\Support\Str::slug($fashion->fashion,' ')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_fashion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md m-0 px-1">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">Category</label>
                                            <select id="category"
                                                    class="form-control <?php $__errorArgs = ['product_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_category">

                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md m-0 px-1">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">SubCategory</label>
                                            <select id="subcategory"
                                                    class="form-control <?php $__errorArgs = ['product_subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_subcategory">
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md m-0 px-1">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">Brand</label>
                                            <select class="form-control <?php $__errorArgs = ['product_brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_brand">
                                                <?php if($brands->isEmpty()): ?>
                                                    <option value="">No Brand Available</option>
                                                <?php else: ?>
                                                    <option value="">Select Brand</option>
                                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($brand->title); ?>">
                                                            <?php echo e(\Illuminate\Support\Str::slug($brand->title,' ')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md m-0 px-1">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">Trader</label>
                                            <select class="form-control <?php $__errorArgs = ['product_trader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_trader">
                                                <?php if($traders->isEmpty()): ?>
                                                    <option value="">No Trader Available</option>
                                                <?php else: ?>
                                                    <option value="">Select Trader</option>
                                                    <?php $__currentLoopData = $traders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($trader->title); ?>">
                                                            <?php echo e(\Illuminate\Support\Str::slug($trader->title,' ')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_trader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div id="filter-selection-container" class="row">
                                    <div id="selection-wrapper" class="col-md-2 m-0 px-1">
                                        <div  class="form-group w-100">
                                            <label for="section" class="form-label">Select Filter</label>
                                            <select id="filter-selection" class="form-control <?php $__errorArgs = ['product_filter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="product_filter">
                                                <?php if($filter_categories->isEmpty()): ?>
                                                    <option value="">No Filter Available</option>
                                                <?php else: ?>
                                                    <option value="">Select Filter</option>
                                                    <option value="reset-filter">Reset Filter</option>
                                                    <?php $__currentLoopData = $filter_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($filter->category); ?>">
                                                            <?php echo e(\Illuminate\Support\Str::slug($filter->category,' ')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['product_filter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="product_title" class="form-label">Title</label>
                                    <input type="text" name="product_title"
                                           class="form-control <?php $__errorArgs = ['product_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="product title..." value="<?php echo e(old('product_title')); ?>">
                                    <?php $__errorArgs = ['product_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="product_title" class="form-label">Discount Price</label>
                                    <input type="number" name="product_discount_price"
                                           class="form-control <?php $__errorArgs = ['product_discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="discount price..." value="<?php echo e(old('product_discount_price')); ?>">
                                    <?php $__errorArgs = ['product_discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="product_title" class="form-label">Price</label>
                                    <input type="number" name="product_price"
                                           class="form-control <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="product price..." value="<?php echo e(old('product_price')); ?>">
                                    <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="custom-file">
                                    <input type="file" name="product_image"
                                           class="custom-file-input <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="custom-file-label">Choose Image</label>
                                    <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <label for="product_title" class="form-label">Specifications</label>
                                        <textarea name="product_specification"
                                                  class="<?php $__errorArgs = ['product_specification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('product_specification')); ?>

                                        </textarea>
                                        <?php $__errorArgs = ['product_specification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="product_title" class="form-label">Features</label>
                                        <textarea name="product_feature"
                                                  class="<?php $__errorArgs = ['product_feature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('product_feature')); ?></textarea>
                                        <?php $__errorArgs = ['product_feature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group mt-3">
                                    <label for="product_title" class="form-label">Description</label>
                                    <textarea name="product_description"
                                              class="<?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('product_description')); ?></textarea>
                                    <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mx-auto">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-outline-primary btn-block">
                                                Create Post
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md">
                <?php if($products !== ""): ?>
                    <table id="data-table" class="table table-hover table-stripe w-100"
                           style="font-size: 16px; width: 100%;">
                        <thead>
                        <th>Image</th>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Section</th>
                        <th>Category</th>
                        <th>Subcategory</th>
                        <th>Fashion</th>
                        <th>Price</th>
                        <th>Discount</th>
                        <th>Brand</th>
                        <th>Trader</th>
                        <th>Action</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>"
                                       class="table-data">
                                        <img class="img-fluid"
                                             src="<?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/'.$product->image)); ?>"
                                             width="50" height="50">
                                    </a>
                                </td>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::slug($product->title,' ')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('view_section_products',\Illuminate\Support\Str::slug($product->section ,'-'))); ?>"
                                       class="table-data">
                                        <?php echo e(\Illuminate\Support\Str::slug($product->section,' ')); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('view_category_products',\Illuminate\Support\Str::slug($product->category ,'-'))); ?>"
                                       class="table-data">
                                        <?php echo e(\Illuminate\Support\Str::slug($product->category,' ')); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('view_subcategory_products',['subcategory'=>\Illuminate\Support\Str::slug($product->subcategory ,'-'),
                                    'category'=>\Illuminate\Support\Str::slug($product->category,'-')])); ?>"
                                       class="table-data">
                                        <?php echo e(\Illuminate\Support\Str::slug($product->subcategory,' ')); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('view_fashion_products',\Illuminate\Support\Str::slug($product->fashion ,'-'))); ?>"
                                       class="table-data">
                                        <?php echo e(\Illuminate\Support\Str::slug($product->fashion,' ')); ?>

                                    </a>
                                </td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->discount); ?></td>
                                <td>
                                    <a href="<?php echo e(route('view_brand_products',\Illuminate\Support\Str::slug($product->brand ,'-'))); ?>"
                                       class="table-data">
                                        <?php echo e($product->brand); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('view_trader_products',\Illuminate\Support\Str::slug($product->trader ,'-'))); ?>"
                                       class="table-data">
                                        <?php echo e($product->trader); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin_edit_product_view',$product->id)); ?>" class="edit-text"
                                       title="edit product">
                                        <i class="far fa-edit"></i>
                                    </a>
                                    &nbsp;
                                    <form class="d-inline" action="<?php echo e(route('delete_product',$product->id)); ?>"
                                          method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="delete-text bg-transparent border-0" title="delete product"><i
                                                class="far fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-center">No Products To Display</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/admin/products.blade.php ENDPATH**/ ?>