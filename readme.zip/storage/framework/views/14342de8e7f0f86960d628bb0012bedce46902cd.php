<?php $__env->startSection('title'); ?>
    PumbaShopping
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(\Illuminate\Support\Facades\Session::has('status')): ?>
        <div class="mt-3 p-3 text-center alert alert-success alert-dismissible show fade">
            <?php echo e(\Illuminate\Support\Facades\Session::get('status')); ?>

            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="container mt-5">
        <div class="row">
            <div id="accordion" class="w-100">
                <div class="card">
                    <div class="card-footer bg-white border-bottom border-top-0">
                        <button class="btn btn-outline-danger" data-toggle="collapse" data-target="#create-product">
                            <i class="fas fa-plus-circle"></i> Create A Section
                        </button>
                    </div>

                    <div class="collapse show" id="create-product" data-parent="#accordion">
                        <div class="card-body">
                            <form
                                action="<?php echo e(route('create_section')); ?>"
                                method="post"
                                enctype="application/x-www-form-urlencoded"
                                id="section_form"
                                name="section_form">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="section_title" class="form-label">Title</label>
                                    <input type="text" name="section_title"
                                           class="form-control <?php $__errorArgs = ['section_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="section title..." value="<?php echo e(old('section_title')); ?>">
                                    <?php $__errorArgs = ['section_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mx-auto">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-outline-danger btn-block">
                                                Create Section
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row px-auto">
            <div class="col-md">
                <?php if($sections !== ""): ?>
                    <table id="data-table" class="table table-bordere table-hover table-stripe w-100"
                           style="font-size: 16px; width: 100%;">
                        <thead>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Action</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($section->id); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::slug($section->title,' ')); ?></td>
                                <td><a href="<?php echo e(route('admin_edit_section_view',$section->id)); ?>" class="edit-text"
                                       title="edit product"><i class="far fa-edit"></i></a>
                                    &nbsp;
                                    <form id="delete_form<?php echo e($section->id); ?>" class="d-inline"
                                          action="<?php echo e(route('delete_section',$section->id)); ?>"
                                          method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="delete-text bg-transparent border-0"
                                                data-toggle="modal" data-target="#confirmation_modal<?php echo e($section->id); ?>"
                                                title="delete section"><i
                                                class="far fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-center">No Sections To Display</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('components.confirmation_modal'); ?>
            <?php $__env->slot('modal_id'); ?>
                <?php echo e($section->id); ?>

            <?php $__env->endSlot(); ?>
            <?php $__env->slot('btn_id'); ?>
                <?php echo e($section->id); ?>

            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/admin/sections.blade.php ENDPATH**/ ?>