<?php $__env->startSection('title'); ?>
    PumbaShopping
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(\Illuminate\Support\Facades\Session::has('status')): ?>
        <div class="mt-3 p-3 text-center alert alert-success alert-dismissible show fade">
            <?php echo e(\Illuminate\Support\Facades\Session::get('status')); ?>

            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="container mt-5">
        <div class="row">
            <div id="accordion" class="w-100">
                <div class="card">
                    <div class="card-footer bg-white border-bottom border-top-0">
                        <button class="btn btn-outline-warning" data-toggle="collapse" data-target="#create-product">
                            <i class="fas fa-plus-circle"></i> Create A Slider
                        </button>
                    </div>

                    <div class="collapse show" id="create-product" data-parent="#accordion">
                        <div class="card-body">
                            <form
                                action="<?php echo e(route('create_slider')); ?>"
                                method="post"
                                enctype="multipart/form-data"
                                id="slider_form"
                                name="slider_form">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md m-0">
                                        <div class="form-group w-100">
                                            <label for="section" class="form-label">Section</label>
                                            <select class="form-control <?php $__errorArgs = ['slider_section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="slider_section">
                                                <?php if($sections->isEmpty()): ?>
                                                    <option value="">No Section Available</option>
                                                <?php else: ?>
                                                    <option value="">Select a Section</option>
                                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($section->title); ?>">
                                                            <?php echo e($section->title); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['slider_section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="custom-file mb-4">
                                    <input type="file" name="slider_image"
                                           class="custom-file-input <?php $__errorArgs = ['slider_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="custom-file-label">Choose Image</label>
                                    <?php $__errorArgs = ['slider_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mx-auto">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-outline-warning btn-block">
                                                Create Slider
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row px-auto">
            <div class="col-md">
                <?php if(!$sliders->isEmpty()): ?>
                    <table id="data-table" class="table table-bordere table-hover table-stripe w-100"
                           style="font-size: 16px; width: 100%;">
                        <thead>
                        <th>Id</th>
                        <th>Image</th>
                        <th>Section</th>
                        <th>Action</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($slider->id); ?></td>
                                <td>
                                    <a href=""
                                       class="table-data">
                                        <img class="img-fluid"
                                             src="<?php echo e(asset('storage/images/sliders/'.$slider->slider_image)); ?>"
                                             width="50" height="50">
                                    </a>

                                </td>
                                <td><?php echo e(\Illuminate\Support\Str::slug($slider->section,' ')); ?></td>
                                <td><a href="<?php echo e(route('admin_edit_slider_view',$slider->id)); ?>" class="edit-text" title="edit slider"><i class="far fa-edit"></i></a>
                                    &nbsp;
                                    <form id="delete_form<?php echo e($slider->id); ?>" class="d-inline" action="<?php echo e(route('delete_slider',$slider->id)); ?>" method="post"
                                          data-toggle="modal" data-target="#confirmation_modal<?php echo e($slider->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="delete-text bg-transparent border-0" title="delete slider"><i
                                                class="far fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-center">No Sliders To Display</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('components.confirmation_modal'); ?>
            <?php $__env->slot('modal_id'); ?>
                <?php echo e($slider->id); ?>

            <?php $__env->endSlot(); ?>
            <?php $__env->slot('btn_id'); ?>
                <?php echo e($slider->id); ?>

            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/admin/sliders.blade.php ENDPATH**/ ?>