<?php $__env->startSection('title'); ?>
    <?php echo e($product->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Product Detail Starts Here -->
    <section id="product-detail" class="my-5">
        <div class="container p-0">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="card zoom-card">
                                        <div id="zoom-on-img"
                                             class="card-body p-0">
                                            <img
                                                src="<?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/resize_'.$product->image)); ?>"
                                                data-src="<?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/'.$product->image)); ?>"
                                                class="img-fluid zoomimg">
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <h3 class="product-title text-truncate"><?php echo e($product->title); ?></h3>
                                            <h3 class="d-inline"><span
                                                    class="text-success product-discount-price">
                                                    <?php if($product->discount != ""): ?>
                                                        Rs.&nbsp;<?php echo e($product->discount); ?>

                                                    <?php else: ?>
                                                        Rs. <?php echo e($product->price); ?>

                                                    <?php endif; ?>
                                                </span>
                                            </h3>&nbsp;<s><small
                                                    class="text-muted product-price">
                                                    <?php if($product->discount != ""): ?>
                                                        Rs.&nbsp;<?php echo e($product->price); ?>

                                                    <?php endif; ?>
                                                </small></s>&nbsp;
                                            <small
                                                class="text-danger product-percentage">
                                                <?php if($product->discount != ""): ?>
                                                    <?php echo e($product->percentage); ?>%&nbsp;Off
                                                <?php endif; ?>
                                            </small><br>
                                        </div>
                                        <div class="col p-0 product-brand mr-2">
                                            <a href="<?php echo e(route('view_brand_products',\Illuminate\Support\Str::slug($brand->title,'-'))); ?>"
                                               class="d-flex align-items-center h-100"><img
                                                    src="<?php echo e(asset('storage/images/brands/'.$brand->image)); ?>"
                                                    title="<?php echo e($brand->image); ?>" class="img-fluid"></a>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="key-feature">
                                                <h5>Key Features</h5>
                                                <?php echo $product->feature; ?>

                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="sold-by">
                                                <h5>Sold By</h5>
                                                <a href="<?php echo e(route('view_trader_products',$product->trader)); ?>"
                                                   class="text-success trader"><?php echo e($product->trader); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card my-3">
                                <div class="card-header p-0 bg-white">
                                    <ul class="nav nav-tabs border-0" role="tablist">
                                        <li class="nav-item border-0">
                                            <a href="#description" data-toggle="tab" class="nav-link">Description</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#return-policy" data-toggle="tab" class="nav-link">Return
                                                Policy</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#specification" data-toggle="tab"
                                               class="nav-link">Specifications</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" role="tabpanel" id="description">
                                            <?php echo $product->description; ?>

                                        </div>
                                        <div class="tab-pane fade" role="tabpanel" id="return-policy">
                                            This is return policy
                                        </div>
                                        <div class="tab-pane fade" role="tabpanel" id="specification">
                                            <?php echo $product->specification; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Product You May Like Starts Here -->
                            <?php if($product_you_may_like->isNotEmpty()): ?>
                                <?php $__env->startComponent('components.rest_card_section'); ?>
                                    <?php $__env->slot('carousel_container_style'); ?>
                                        box-shadow:none;
                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('section_title'); ?>
                                        <?php echo e($product_you_may_like_title); ?>

                                    <?php $__env->endSlot(); ?>

                                    <?php $__env->slot('section_carousel_id'); ?>
                                        <?php echo e($product_you_may_like_title); ?>


                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('product_container'); ?>
                                        <?php $__currentLoopData = $product_you_may_like; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div id="card-inner-container" class="owl-item">
                                                <?php $__env->startComponent('components.product_card'); ?>
                                                    <?php $__env->slot('product_img_url'); ?>
                                                        <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                                        <?php $__env->slot('image_source'); ?>
                                                            <?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/resize_'.$product->image)); ?>

                                                        <?php $__env->endSlot(); ?>
                                                    <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('product_title_url'); ?>
                                                        <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                                        <?php $__env->slot('product_title'); ?>
                                                            <?php echo e($product->title); ?>

                                                        <?php $__env->endSlot(); ?>
                                                    <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('discount_price'); ?>
                                                        <?php if($product->discount != ""): ?>
                                                            <span
                                                                class="text-success">Rs.&nbsp<?php echo e($product->discount); ?></span>
                                                        <?php endif; ?>
                                                    <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('original_price'); ?>
                                                        <?php if($product->discount != ""): ?>
                                                            &nbsp<s
                                                                class="text-muted"><small>Rs.&nbsp<?php echo e($product->price); ?></small></s>
                                                        <?php else: ?>
                                                            &nbsp<span
                                                                class="text-success">Rs.&nbsp<?php echo e($product->price); ?></span>
                                                        <?php endif; ?>

                                                    <?php $__env->endSlot(); ?>

                                                    <?php $__env->slot('discount_percentage'); ?>
                                                        <?php if($product->discount != ""): ?>
                                                            &nbsp;<span
                                                                class="text-danger"><?php echo e($product->percentage); ?>% Off</span>
                                                        <?php endif; ?>
                                                    <?php $__env->endSlot(); ?>
                                                <?php echo $__env->renderComponent(); ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('section_carousel_id'); ?>
                                        <?php echo e(\Illuminate\Support\Str::slug($product_you_may_like_title,'-')); ?>

                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('owl_prev_id'); ?>
                                        Best Of Category-prev
                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('carousel_id'); ?>
                                        '<?php echo e(\Illuminate\Support\Str::slug($product_you_may_like_title,'-')); ?>'
                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('owl_prev_id'); ?>
                                        'Best Of Category-prev'
                                    <?php $__env->endSlot(); ?>
                                    <?php $__env->slot('owl_next_id'); ?>
                                        'Best Of Category-next'
                                <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                        <?php endif; ?>
                        <!-- Product You May Like Ends Here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product Detail Ends Here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make(\Illuminate\Support\Facades\Auth::guard('admin')->check() ?'layout.admin_app':'layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/project_rest_layout/product_detail.blade.php ENDPATH**/ ?>