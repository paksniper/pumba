<?php $__env->startSection('title'); ?>
    PumbaShopping
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Slide Show Starts Here -->

    <section id="slide-show">

        <div class="row">
            <div id="main-slide-show" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>" style="width: 100%;">
                            <a href="<?php echo e(route('view_section_products',$slider->section)); ?>">
                                <img class="img-fluid slide-img w-100"
                                     src="<?php echo e(asset('storage/images/sliders/'.$slider->slider_image)); ?>">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="#main-slide-show" class="carousel-control-prev" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a href="#main-slide-show" class="carousel-control-next" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>
    </section>
    <!-- Slide Show Ends Here -->
    <?php if(!$products->isEmpty()): ?>
        <?php $count = 0; ?>
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__env->startComponent('components.card_section'); ?>
                <?php $__env->slot('section_title'); ?>
                    <?php echo e(\Illuminate\Support\Str::slug($section," ")); ?>

                <?php $__env->endSlot(); ?>
                <?php $__env->slot('section_view_url'); ?>
                    <?php echo e(route('view_section_products',\Illuminate\Support\Str::slug($section,'-'))); ?>

                <?php $__env->endSlot(); ?>
                <?php $__env->slot('section_carousel_id'); ?>
                    <?php echo e($section); ?>

                    
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('product_container'); ?>
                    <?php $__currentLoopData = $products[$count]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="card-inner-container" class="owl-item">
                            <?php $__env->startComponent('components.product_card'); ?>
                                <?php $__env->slot('product_img_url'); ?>
                                    <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                    <?php $__env->slot('image_source'); ?>
                                        <?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/resize_'.$product->image)); ?>

                                    <?php $__env->endSlot(); ?>
                                <?php $__env->endSlot(); ?>

                                <?php $__env->slot('product_title_url'); ?>
                                    <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                    <?php $__env->slot('product_title'); ?>
                                        <?php echo e($product->title); ?>

                                    <?php $__env->endSlot(); ?>
                                <?php $__env->endSlot(); ?>

                                <?php $__env->slot('discount_price'); ?>
                                    <?php if($product->discount != ""): ?>
                                        <span class="text-success">Rs.&nbsp<?php echo e($product->discount); ?></span>
                                    <?php endif; ?>
                                <?php $__env->endSlot(); ?>

                                <?php $__env->slot('original_price'); ?>
                                    <?php if($product->discount != ""): ?>
                                        &nbsp<s
                                            class="text-muted"><small>Rs.&nbsp<?php echo e($product->price); ?></small></s>
                                    <?php else: ?>
                                        &nbsp<span class="text-success">Rs.&nbsp<?php echo e($product->price); ?></span>
                                    <?php endif; ?>

                                <?php $__env->endSlot(); ?>

                                <?php $__env->slot('discount_percentage'); ?>
                                    <?php if($product->discount != ""): ?>
                                        &nbsp;<span class="text-danger"><?php echo e($product->percentage); ?>% Off</span>
                                    <?php endif; ?>
                                <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('section_carousel_id'); ?>
                    <?php echo e(\Illuminate\Support\Str::slug($section,'-')); ?>

                <?php $__env->endSlot(); ?>
                <?php $__env->slot('owl_prev_id'); ?>
                    <?php echo e($section); ?>-prev
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('carousel_id'); ?>
                    '<?php echo e(\Illuminate\Support\Str::slug($section,'-')); ?>'
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('owl_prev_id'); ?>
                    '<?php echo e(\Illuminate\Support\Str::slug($section,'-')); ?>-prev'
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('owl_next_id'); ?>
                    '<?php echo e(\Illuminate\Support\Str::slug($section,'-')); ?>-next'
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
            <?php $count++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="card col-md-6 border-0 mt-5 offset-md-3 text-center text-capitalize">
            <div class="card-body alert alert-danger">
                Sorry no product is available
            </div>
        </div>
    <?php endif; ?>
    <br>
    <br>
    <!--  Feature Brands Starts Here -->
    <?php if(!$feature_brands->isEmpty()): ?>
        <?php $__env->startComponent('components.rest_card_section'); ?>
            <?php $__env->slot('carousel_container_style'); ?>

            <?php $__env->endSlot(); ?>
            <?php $__env->slot('section_title'); ?>
                <?php echo e($feature_brands_title); ?>

            <?php $__env->endSlot(); ?>

            <?php $__env->slot('section_carousel_id'); ?>
                <?php echo e($feature_brands_title); ?>


            <?php $__env->endSlot(); ?>
            <?php $__env->slot('product_container'); ?>
                <?php $__currentLoopData = $feature_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="card-inner-container" class="owl-item my-4">
                        <?php $__env->startComponent('components.brand_card'); ?>
                            <?php $__env->slot('product_img_url'); ?>
                                <?php echo e(route('view_brand_products',\Illuminate\Support\Str::slug($brand->title ,'-'))); ?>

                                <?php $__env->slot('image_source'); ?>
                                    <?php echo e(asset('storage/images/brands/'.$brand->image)); ?>

                                <?php $__env->endSlot(); ?>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('section_carousel_id'); ?>
                <?php echo e(\Illuminate\Support\Str::slug($feature_brands_title,'-')); ?>

            <?php $__env->endSlot(); ?>
            <?php $__env->slot('owl_prev_id'); ?>
                Best Of Category-prev
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('carousel_id'); ?>
                '<?php echo e(\Illuminate\Support\Str::slug($feature_brands_title,'-')); ?>'
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('owl_prev_id'); ?>
                'Best Of Category-prev'
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('owl_next_id'); ?>
                'Best Of Category-next'
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
    <!--  Feature Brands End Here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make(\Illuminate\Support\Facades\Auth::guard('admin')->check() ?'layout.admin_app':'layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/home.blade.php ENDPATH**/ ?>