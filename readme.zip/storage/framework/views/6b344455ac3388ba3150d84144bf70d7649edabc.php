<?php $__env->startSection('title'); ?>
    PumbaShopping
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div id="accordion" class="w-100">
                <div class="card">
                    <div class="card-footer bg-white border-bottom border-top-0">
                        <button class="btn btn-outline-light text-dark" data-toggle="collapse" data-target="#create-product">
                            <i class="far fa-edit"></i> Update A Subcategory
                        </button>
                    </div>

                    <div class="collapse show" id="create-product" data-parent="#accordion">
                        <div class="card-body">
                            <form
                                action="<?php echo e(route('post_edit_subcategory',$subcategory->id)); ?>"
                                method="post"
                                enctype="application/x-www-form-urlencoded"
                                id="subcategory_form"
                                name="subcategory_form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="original_subcategory" value="<?php echo e($subcategory->subcategory); ?>">
                                <div class="col-md m-0 px-1">
                                    <div class="form-group w-100">
                                        <label for="category" class="form-label">Category</label>
                                        <select class="form-control <?php $__errorArgs = ['subcategory_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="subcategory_category">
                                            <option value="<?php echo e($subcategory->category); ?>"><?php echo e($subcategory->category); ?></option>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['subcategory_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger" style="font-size: 15px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="subcategory_title" class="form-label">Title</label>
                                    <input type="text" name="subcategory_title"
                                           class="form-control <?php $__errorArgs = ['subcategory_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="Subcategory title..." value="<?php echo e($subcategory->subcategory); ?>">
                                    <?php $__errorArgs = ['subcategory_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mx-auto">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-outline-light btn-block text-dark">
                                                Update Subcategory
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/admin/edit_subcategories.blade.php ENDPATH**/ ?>