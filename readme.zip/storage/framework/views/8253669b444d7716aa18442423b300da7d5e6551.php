<nav id="store-navbar" class="navbar navbar-expand-sm navbar-dark p-0">
    <div class="container">
        <a href="/" class="navbar-brand pt-0 mr-0 "><img src='<?php echo e(asset("images/pumbastore.png")); ?>'
                                                         class="img-responsive"></a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#mynavbar"><span
                class="navbar-toggler-icon"></span></button>
        <div id="mynavbar" class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item ml-3" style="position:relative;">
                    <form action="<?php echo e(route('productSubmitSearch')); ?>" class="form-inline" name="search-form"
                          id="search-form" method="GET"
                          enctype="application/x-www-form-urlencoded">
                        
                        <div class="input-group">
                            <select id="nav-categories" name="category" class="custom-select input-group-prepend py-0">
                                <option value="all">All</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->title); ?>"><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="text" name="search-input" id="search-input"
                                   placeholder="Search product here..." onkeyup="searchProduct()" class="form-control"
                                   style="width: 400px;">
                            <button id="search-submit-btn" type="submit" class="btn btn-light input-group-append">
                                <span class="fas fa-search"></span>
                            </button>
                        </div>
                    </form>
                    <ul class="border w-100 pl-0 bg-white suggested-product"></ul>
                </li>
                <li class="nav-item ml-4">
                    <a href="#" class="nav-link"><span class="fas fa-home"></span> &nbsp;Home</a>
                </li>
                <li class="nav-item ml-3">
                    <a href="#" class="nav-link"><span class="fas fa-headset"></span> &nbsp;Customer Service</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/vagrant/code/pumbashopping/resources/views/components/navigation_section.blade.php ENDPATH**/ ?>