<?php $__env->startSection('content'); ?>
    <!-- Displaying All Products Start Here -->
    <section id="product-detail" class="my-5">
        <div class="container p-0">
            <div class="row">
                <div class="col-md-3 h-auto border p-0 filter-section categories-container" id="<?php echo e($container_id); ?>"
                     title="<?php echo e($container_value); ?>">
                    <div class="p-2 border-bottom-0">
                        <h6 class="font-weight-bold">FILTERS</h6>
                    </div>
                    <div class="card mb-3 border-top-0 border-left-0 border-right-0 rounded-0 border-bottom">
                        <div class="card-header border-bottom border-top p-2 bg-white categories-btn">
                            <div class="card-text float-left" style="font-size: 15px;">Categories</div>
                            <span class="float-right fas fa-angle-up cat-slide-icon mt-1"></span>
                        </div>
                        <div class="card-body p-0 pl-1">
                            <ul class="list-unstyled categories mCustomScrollbar" data-mcs-theme="dark"
                                id="<?php echo e($fashion_value); ?>">
                                <?php if(!empty($fp)): ?>
                                    <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="fashionyo_<?php echo e($fp); ?>">
                                            <label class="custom-control-label" for="fashionyo_<?php echo e($fp); ?>">
                                                    <span class="mb-1 d-block text-truncate subcategory-item-container"
                                                          style="width: 200px;"><?php echo e($fp); ?></span>
                                            </label>
                                        </div>
                                    </li>
                                <?php elseif(!empty($cp)): ?>
                                    <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input"
                                                   id="categoryyo_<?php echo e($cp); ?>">
                                            <label class="custom-control-label" for="categoryyo_<?php echo e($cp); ?>">
                                                    <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                          style="width: 200px;"><?php echo e($cp); ?></span>
                                            </label>
                                        </div>
                                    </li>
                                <?php elseif(!empty($scp) && !empty($categoryForSubcategory)): ?>
                                    <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input"
                                                   id="<?php echo e($scp); ?>">
                                            <input type="hidden" id="ajax-subcategory" value="<?php echo e($scp); ?>">
                                            <label class="custom-control-label" for="<?php echo e($scp); ?>">
                                                    <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                          style="width: 200px;"><?php echo e($scp); ?></span>
                                            </label>
                                        </div>
                                    </li>
                                <?php elseif(!empty($sp)): ?>
                                    <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input"
                                                   id="sectionyo_<?php echo e($section); ?>">
                                            <label class="custom-control-label" for="sectionyo_<?php echo e($section); ?>">
                                                    <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                          style="width: 200px;"><?php echo e($section); ?></span>
                                            </label>
                                        </div>
                                    </li>
                                    <?php $__currentLoopData = $sectionSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($subcategory); ?>">
                                                <label class="custom-control-label" for="<?php echo e($subcategory); ?>">
                                                        <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                              style="width: 200px;"><?php echo e($subcategory); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif(!empty($pb)): ?>
                                    <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input"
                                                   id="brandyo_<?php echo e($brand); ?>">
                                            <label class="custom-control-label" for="brandyo_<?php echo e($brand); ?>">
                                                    <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                          style="width: 200px;"><?php echo e($brand); ?></span>
                                            </label>
                                        </div>
                                    </li>
                                    <?php $__currentLoopData = $brandSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($subcategory); ?>">
                                                <label class="custom-control-label" for="<?php echo e($subcategory); ?>">
                                                        <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                              style="width: 200px;"><?php echo e($subcategory); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif(!empty($tp)): ?>
                                    <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input"
                                                   id="traderyo_<?php echo e($trader); ?>">
                                            <label class="custom-control-label" for="traderyo_<?php echo e($trader); ?>">
                                                    <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                          style="width: 200px;"><?php echo e($trader); ?></span>
                                            </label>
                                        </div>
                                    </li>
                                    <?php $__currentLoopData = $traderSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($subcategory); ?>">
                                                <label class="custom-control-label" for="<?php echo e($subcategory); ?>">
                                                        <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                              style="width: 200px;"><?php echo e($subcategory); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif(!empty($searchProduct)): ?>
                                    <?php $__currentLoopData = $searchSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-truncate d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($subcategory); ?>">
                                                <label class="custom-control-label" for="<?php echo e($subcategory); ?>">
                                                        <span class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                              style="width: 200px;"><?php echo e($subcategory); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(!empty($fashionCategories)): ?>
                                    <?php $__currentLoopData = $fashionCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($category); ?>">
                                                <label class="custom-control-label" for="<?php echo e($category); ?>">
                                            <span
                                                class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                style="width: 200px;"><?php echo e(\Illuminate\Support\Str::slug($category," ")); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif(!empty($catSubCategories)): ?>
                                    <?php $__currentLoopData = $catSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li class="d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($subcategory); ?>">
                                                <label class="custom-control-label" for="<?php echo e($subcategory); ?>">
                                            <span
                                                class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                style="width: 200px;"><?php echo e(\Illuminate\Support\Str::slug($subcategory," ")); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif(!empty($subCategorie)): ?>
                                    <a href="<?php echo e(route('view_subcategory_products',['$subcategory'=>\Illuminate\Support\Str::slug($subcat,'-'),'category'=>\Illuminate\Support\Str::slug($categoryForSubcategory,'-')])); ?>"
                                       class="subcategory-item-container">
                                        <li class="d-block py-2 align-items-center px-2 subcategory-item">
                                            <span
                                                class="ml-3 d-inline-block text-truncate subcategory-item-container"
                                                style="width: 200px;"><?php echo e(\Illuminate\Support\Str::slug($subcat," ")); ?></span>
                                        </li>
                                    </a>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>
                    <div class="card border-top-0 mb-3 w-100 border-left-0 border-right-0 rounded-0 border-bottom">
                        <div class="card-header bg-white border border-left-0 border-right-0 border-bottom-1 px-3 py-1">
                            <div class="card-title" style="font-size: 15px;">
                                Price
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <input type="text" min="<?php echo e($min_price); ?>" max="<?php echo e($max_price); ?>"
                                           oninput="validity.valid||(value='<?php echo e($min_price); ?>');"
                                           id="min_price"
                                           class="price-range-field w-75 border-left-dark" value="<?php echo e($min_price); ?>"/>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" min="<?php echo e($min_price); ?>" max="<?php echo e($max_price); ?>"
                                           oninput="validity.valid||(value='<?php echo e($max_price); ?>');"
                                           id="max_price" class="price-range-field w-75"/>
                                </div>
                            </div>
                            <div id="slider-range" class="price-filter-range w-100" name="rangeInput"
                                 style="height: 5px;">
                            </div>
                            <div id="price-display" style="font-size: 14px;">Rs.&nbsp;<span
                                    id="price_small">&nbsp;<?php echo e($min_price); ?></span>&nbsp;- &nbsp;<span
                                    id="price_large"><?php echo e($max_price); ?></span></div>
                        </div>
                    </div>
                    <div class="card border-top-0 border-left-0 border-right-0 rounded-0 border-bottom">
                        <div class="card-header border-bottom border-top bg-white brands-btn">
                            <div class="card-text float-left" style="font-size: 15px;">Brands</div>
                            <span class="float-right fas fa-angle-up brand-slide-icon mt-1"></span>
                        </div>
                        <div class="card-body brands-container p-1">
                            <ul class="list-unstyled brands mCustomScrollbar" id="brand" data-mcs-theme="dark">
                                <?php
                                    $brand_count = 0;
                                ?>
                                <?php while($brand_count < $brand_counter): ?>
                                    <?php $__currentLoopData = $product_brands[$brand_count]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="d-block py-2 align-items-center px-2 subcategory-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input"
                                                       id="<?php echo e($brand->title); ?>">
                                                <label class="custom-control-label" for="<?php echo e($brand->title); ?>">
                                            <span
                                                class="mb-1 d-inline-block text-truncate subcategory-item-container"
                                                style="width: 200px;"><?php echo e(\Illuminate\Support\Str::slug($brand->title," ")); ?></span>
                                                </label>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $brand_count++;
                                    ?>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    </div>
                    <div id="filter-container">
                        <?php if($filter_html !== ''): ?>
                            <?php echo $filter_html; ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-9 view-products-container">
                    <?php if($best_of_category->isNotEmpty()): ?>
                        <?php $__env->startComponent('components.rest_card_section'); ?>
                            <?php $__env->slot('carousel_container_style'); ?>
                                box-shadow:none;
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('section_title'); ?>
                                <?php echo e($best_of_category_title); ?>

                            <?php $__env->endSlot(); ?>

                            <?php $__env->slot('section_carousel_id'); ?>
                                <?php echo e($best_of_category_title); ?>


                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('product_container'); ?>
                                <?php $__currentLoopData = $best_of_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div id="card-inner-container" class="owl-item">
                                        <?php $__env->startComponent('components.product_card'); ?>
                                            <?php $__env->slot('product_img_url'); ?>
                                                <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                                <?php $__env->slot('image_source'); ?>
                                                    <?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/resize_'.$product->image)); ?>

                                                <?php $__env->endSlot(); ?>
                                            <?php $__env->endSlot(); ?>

                                            <?php $__env->slot('product_title_url'); ?>
                                                <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                                <?php $__env->slot('product_title'); ?>
                                                    <?php echo e($product->title); ?>

                                                <?php $__env->endSlot(); ?>
                                            <?php $__env->endSlot(); ?>

                                            <?php $__env->slot('discount_price'); ?>
                                                <?php if($product->discount != ""): ?>
                                                    <span class="text-success">Rs.&nbsp<?php echo e($product->discount); ?></span>
                                                <?php endif; ?>
                                            <?php $__env->endSlot(); ?>

                                            <?php $__env->slot('original_price'); ?>
                                                <?php if($product->discount != ""): ?>
                                                    &nbsp<s
                                                        class="text-muted"><small>Rs.&nbsp<?php echo e($product->price); ?></small></s>
                                                <?php else: ?>
                                                    &nbsp<span
                                                        class="text-success">Rs.&nbsp<?php echo e($product->price); ?></span>
                                                <?php endif; ?>

                                            <?php $__env->endSlot(); ?>

                                            <?php $__env->slot('discount_percentage'); ?>
                                                <?php if($product->discount != ""): ?>
                                                    &nbsp;<span
                                                        class="text-danger"><?php echo e($product->percentage); ?>% Off</span>
                                                <?php endif; ?>
                                            <?php $__env->endSlot(); ?>
                                        <?php echo $__env->renderComponent(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('section_carousel_id'); ?>
                                <?php echo e(\Illuminate\Support\Str::slug($best_of_category_title,'-')); ?>

                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('owl_prev_id'); ?>
                                Best Of Category-prev
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('carousel_id'); ?>
                                '<?php echo e(\Illuminate\Support\Str::slug($best_of_category_title,'-')); ?>'
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('owl_prev_id'); ?>
                                'Best Of Category-prev'
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('owl_next_id'); ?>
                                'Best Of Category-next'
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    <?php endif; ?>
                    <div class="card bg-white">
                        <div class="card-header bg-white" id="product-result-status">
                            <?php if($viewproducts !== ""): ?>
                                <?php if(!empty($pb)): ?>
                                    <span class="view-header"><?php echo e($pb); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php elseif(!empty($cp)): ?>
                                    <span class="view-header"><?php echo e($cp); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php elseif(!empty($scp)): ?>
                                    <span class="view-header"><?php echo e($scp); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php elseif(!empty($fp)): ?>
                                    <span class="view-header"><?php echo e($fp); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php elseif(!empty($tp)): ?>
                                    <span class="view-header"><?php echo e($tp); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php elseif(!empty($searchProduct)): ?>
                                    <span class="view-header"><?php echo e($searchProduct); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php elseif(!empty($sp)): ?>
                                    <span class="view-header"><?php echo e($sp); ?>&nbsp;(<?php echo e($count); ?> Products Found)</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="view-header"> No Product Found</span>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <?php
                                $count = 0;
                            ?>
                            <div class="row mb-2" id="product-wrapper">
                                <?php if(!$viewproducts->isEmpty()): ?>
                                    <?php $__currentLoopData = $viewproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 px-1 product-on-view">
                                            <?php $__env->startComponent('components.product_card'); ?>
                                                <?php $__env->slot('product_img_url'); ?>
                                                    <?php echo e(route('product_detail',\Illuminate\Support\Str::slug($product->title ,'-'))); ?>

                                                    <?php $__env->slot('image_source'); ?>
                                                        <?php echo e(asset('storage/images/'.Str::slug($product->fashion,'-').'/'.Str::slug($product->category,'-').'/'.Str::slug($product->subcategory,'-').'/'.$product->image)); ?>

                                                    <?php $__env->endSlot(); ?>
                                                <?php $__env->endSlot(); ?>

                                                <?php $__env->slot('product_title_url'); ?>
                                                    <?php echo e(route('product_detail',$product->image )); ?>

                                                    <?php $__env->slot('product_title'); ?>
                                                        <?php echo e($product->title); ?>

                                                    <?php $__env->endSlot(); ?>
                                                <?php $__env->endSlot(); ?>

                                                <?php $__env->slot('discount_price'); ?>
                                                    <?php if($product->discount != ""): ?>
                                                        <span class="text-success">Rs.&nbsp<?php echo e($product->discount); ?></span>
                                                    <?php endif; ?>
                                                <?php $__env->endSlot(); ?>

                                                <?php $__env->slot('original_price'); ?>
                                                    <?php if($product->discount != ""): ?>
                                                        &nbsp<s
                                                            class="text-muted"><small>Rs.&nbsp<?php echo e($product->price); ?></small></s>
                                                    <?php else: ?>
                                                        &nbsp<span
                                                            class="text-success">Rs.&nbsp<?php echo e($product->price); ?></span>
                                                    <?php endif; ?>

                                                <?php $__env->endSlot(); ?>

                                                <?php $__env->slot('discount_percentage'); ?>
                                                    <?php if($product->discount != ""): ?>
                                                        &nbsp;<span
                                                            class="text-danger"><?php echo e($product->percentage); ?>% Off</span>
                                                    <?php endif; ?>
                                                <?php $__env->endSlot(); ?>
                                            <?php echo $__env->renderComponent(); ?>
                                            <?php
                                                $count++;
                                            ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Pagination starts here -->
                    <div class="row mt-5">
                        <div class="col showing-page-tag">
                            <?php if(!empty($count)): ?>
                                Showing Page <?php echo e($viewproducts->currentPage()); ?> of <?php echo e($viewproducts->lastPage()); ?>

                            <?php endif; ?>
                        </div>
                        <div class="col d-flex justify-content-end">
                            <?php if(!empty($count)): ?>
                                <?php echo e($viewproducts->links()); ?>

                            <?php endif; ?>
                        </div>

                    </div>
                    <!-- Pagination ends here -->
                </div>
            </div>
        </div>
    </section>
    <!-- Product Detail Ends Here -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pumbashopping/resources/views/project_rest_layout/view_all_products.blade.php ENDPATH**/ ?>