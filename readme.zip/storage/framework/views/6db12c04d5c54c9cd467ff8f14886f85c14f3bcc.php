<div class="card border-0 rounded-0 product-card">
    <a href="<?php echo e($product_img_url); ?>">
        <img class="img-fluid card-img-top"  src="<?php echo e($image_source); ?>">
    </a>
</div>
<?php /**PATH /home/vagrant/code/pumbashopping/resources/views/components/brand_card.blade.php ENDPATH**/ ?>