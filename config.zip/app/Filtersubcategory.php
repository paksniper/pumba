<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Filtersubcategory extends Model
{
    protected $fillable = [
        'category','subcategory'
    ];
}
