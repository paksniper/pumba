<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Filtercategory extends Model
{
    protected $fillable = [
        'fashion','category'
    ];
}
