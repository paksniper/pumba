<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trader extends Model
{
    //
}
